

//点击显示X关闭
$(function () {
    var getway=0;
    $(".getway").click(function () {
        if(getway%2==0){
            getway++;
//          $(this).attr('src','img/off%20(1).png');
            $(".ph-ul").css("height","450px")
        }else {
            getway++;
            $(this).attr('src','img/off%20(2).png');
            $(".ph-ul").css("height","0")
        }
    })
})










$( document ).ready(function() {
    
    $(function () {
        var s1 = parseInt($(".banner").offset().top);
        var s2 = parseInt($(".section1").offset().top);
        var s3 = parseInt($(".section3").offset().top);
        var s4 = parseInt($(".section4").offset().top);
        var s5 = parseInt($(".section5").offset().top);
        $(".list li:nth-child(1),.ph-ul li:nth-child(1)").click(function () {
            $('body,html').animate({scrollTop: (s1-60)}, 800);
            $(".list li").removeClass("active-list");
            $(this).addClass("active-list");
            $(".ph-ul").css("height","0")
        });
        
        $(".list li:nth-child(2),.ph-ul li:nth-child(2)").click(function () {
            $('body,html').animate({scrollTop: (s2-60)}, 800);
            $(".list li").removeClass("active-list");
            $(this).addClass("active-list");
            $(".ph-ul").css("height","0")
        });
        $(".list li:nth-child(3),.ph-ul li:nth-child(3)").click(function () {
            $('body,html').animate({scrollTop: (s3-60)}, 800);
            $(".list li").removeClass("active-list");
            $(this).addClass("active-list");
            $(".ph-ul").css("height","0")
        });
        $(".list li:nth-child(4),.ph-ul li:nth-child(4)").click(function () {
            $('body,html').animate({scrollTop: (s4-60)}, 800);
            $(".list li").removeClass("active-list");
            $(this).addClass("active-list");
            $(".ph-ul").css("height","0")
        });
        $(".list li:nth-child(5),.ph-ul li:nth-child(5)").click(function () {
            $('body,html').animate({scrollTop: (s5-60)}, 800);
            $(".list li").removeClass("active-list");
            $(this).addClass("active-list");
            $(".ph-ul").css("height","0")
        });


    });
    
});


// var window_w=window.innerWidth;
// if(window_w<700){
//     $(function () {
//         var wrap=$(".s1-content");
//         setInterval(function () {
//             var left=parseInt(Math.random()*(96-10+1)+10,10);
//             // // var box="<img class=\"money\" src=\"img/m.png\" alt=\"\">";
//             // // box.css("left",left+"%");
//             // // $(wrap).append(box);\
//             var money=document.createElement('img');
//             money.src='img/m.png';
//             money.className='money';
//             money.style.left=left+"%";
//             wrap[0].append(money);
//             if($(".money").length>20){
//                 $(".money")[0].remove();
//                 $(".money")[1].remove();
//                 $(".money")[2].remove();
//                 $(".money")[3].remove();
//                 $(".money")[4].remove();
//                 $(".money")[5].remove();
//                 $(".money")[6].remove();
//                 $(".money")[7].remove();
//
//             }
//         },500)
//     });
// }



































