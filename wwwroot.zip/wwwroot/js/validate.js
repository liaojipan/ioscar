
$(function () {
    var reg=/^1(3|4|5|7|8)\d{9}$/;
    function countdown(times,tx_dom){
        var settimes = times;
        var setInter= setInterval(function() {
            settimes--;
            var oldtime=$(tx_dom).text();
            if (oldtime == 0) {
                //console.log(settimes)
                 $(".rec-code").removeAttr("disabled");//启用按钮
                tx_dom.text("code").removeClass("hui");
                clearInterval(setInter)
            } else {
                tx_dom.text(settimes).addClass("hui");
            }
        },1000);
    }

    $(".rec-code").click(function () {

        var val=$(".ph").val();
        if(val.length>=6){
            $(".ph-err").text("");
            var times=180;
            var tx_dom=$(".rec-code");
                $(".rec-code").attr("disabled", "true");//不能点击
            countdown(times,tx_dom)
        }else {
            $(".ph-err").text("Incorrect phone number");
            $(".ph-err2").text("错误的电话号码");
            $(".ph-err3").text("錯誤的電話號碼");

        }
        
        
    })

    $(".code").blur(function () {
        var val=$(this).val();
        if(val.length<=0){
            $(".code-err").text("Cannot be empty");
          	$(".code-err2").text("不能为空");
          	$(".code-err3").text("不能爲空");
        }else {
            $(".code-err").text("")
        }
    })
//钱包地址
//  $(".adress").blur(function () {
//      var val=$(this).val();
//      if(val.length<=0){
//          $(".adress-err").text("Cannot be empty");
//           $(".adress-err2").text("不能为空")
//
//      }else{
//          $(".adress-err").text("")
//      }
//  })
//

       
   
//    数据提交AJAX  TODO
    $(".lingqu").click(function () {
      var xial=$('#xiala').val();
       var ph=$(".ph").val();//手机号码
       var code=$(".code").val();//文本框的值
//      //判断手机号码是否存在和正确，地址是否填写
        if(ph.length==11 && code.length==6){
            $.ajax({
                url:"/sms.php",
                data:{
                    "mobile":xial + ph,
                    "content":"验证码" + code,
                    "act":'checkcode',
                },
                type:"POST",
                dataType: "json",
                success:function(data){
                    console.log(data);
                    if(data.status == 0){
                        document.location.href= 'candycn.html';
                    } else {
                        alert(data.message);
                    }
                }
            });

        }
        else {
               alert("手机号或验证码错误");
        }

    });
    

    
   
//    数据提交AJAX  TODO
    $(".lingquen").click(function () {
      var xial=$('#xiala').val();
       var ph=$(".ph").val();//手机号码
       var code=$(".code").val();//文本框的值
//      //判断手机号码是否存在和正确，地址是否填写
        if(ph.length==11 && code.length==6){
            $.ajax({
                url:"/sms.php",
                data:{
                    "mobile":xial + ph,
                    "content":"验证码" + code,
                  //  判断验证码是否正确
                    "act":'checkcode',
                },
                type:"POST",
                dataType: "json",
                success:function(data){
                    console.log(data);
                    if(data.status == 0){
                        document.location.href= 'candyen.html';
                    } else {
                        alert(data.message);
                    }
                }
            });

        }else {
               alert("Information is wrong");   
        }
    });
    
    //    数据提交AJAX  TODO
    $(".lingqutw").click(function () {
      var xial=$('#xiala').val();
       var ph=$(".ph").val();//手机号码
       var code=$(".code").val();//文本框的值
//      //判断手机号码是否存在和正确，地址是否填写
        if(ph.length==11 && code.length==6){
            $.ajax({
                url:"/sms.php",
                data:{
                    "mobile":xial + ph,
                    "content":"验证码" + code,
                    "act":'checkcode',
                },
                type:"POST",
                dataType: "json",
                success:function(data){
                    console.log(data);
                    if(data.status == 0){
                        document.location.href= 'candytw.html';
                    } else {
                        alert(data.message);
                    }
                }
            });

        }else {
               alert("手機號或驗證碼錯誤");   
        }
    });
    
    
    
    
    
    
    
    
   //手机验证码
    $(".rec-code").click(function () {
    	var xial=$('#xiala').val();
  	    var mobile =$('.ph').val();//获取文本框的值
    	$.ajax({
//  		           地址
                url:"/sms.php",
//              数据源
                data:{
                    "mobile":xial + mobile,
                    "act":'send',
                },
//              传输方式
                type:"POST",
//              返回格式
                dataType: "json",
                
                success:function(data){
//              	判断
                	if(data.status == 0){
                		alert("发送成功");
                	} else {
                		alert(data.message);
                	}
                }
            });
              
})
    
    $(".copy-candy").click(function () {
        var v=document.getElementById("area");
        v.select();
        document.execCommand("Copy");
        alert("Be replicated")
    })


});
