// var vertexHeight = 15000;
// var planeDefinition = 100;
var planeSize =1245000;
var totalObjects = 100000;
var frame = 0;

var container = document.createElement('div');
document.body.appendChild( container );

var camera = new THREE.PerspectiveCamera(100, window.innerWidth / window.innerHeight,3, 70000);
//方向
camera.position.z = 550000;
camera.position.y =50000;
camera.lookAt( new THREE.Vector3(0,100000,0) );


var scene = new THREE.Scene();
scene.fog = new THREE.Fog( '#CABE99', 1, 100000 );

var uniforms =
    {
      time: { type: "f", value: 0.0 }
    };


	var material = new THREE.ShaderMaterial( {
            uniforms: uniforms,
            vertexShader: document.getElementById( 'vertexShader' ).textContent,
            fragmentShader: document.getElementById( 'fragmentShader' ).textContent,
            wireframe: true,
    fog: false
				} );



// var	plane = new THREE.Mesh( new THREE.PlaneGeometry( planeSize, planeSize, planeDefinition, planeDefinition ), material );
// plane.rotation.x -=Math.PI*.5;
//
// scene.add( plane );

var geometry = new THREE.Geometry();

for (i = 0; i < totalObjects; i ++)
{
  var vertex = new THREE.Vector3();
  vertex.x = Math.random()*planeSize-(planeSize*.5);
  vertex.y = (Math.random()*100000)+10000;
  vertex.z = Math.random()*planeSize-(planeSize*.5);
  geometry.vertices.push( vertex );
}
//大小
var material = new THREE.ParticleBasicMaterial({color:'#CABE99',size: 300 });
var particles = new THREE.ParticleSystem( geometry, material );

	 
scene.add( particles ); 

var renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
container.appendChild( renderer.domElement );



render();

			function render() {
        requestAnimationFrame( render );
//            速度
      camera.position.z -= 150;
           uniforms.time.value = frame;
        frame += .04;
       //  dateVerts();
        renderer.render( scene, camera );
			}



