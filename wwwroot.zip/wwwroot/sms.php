<?php
session_start();
ini_set('date.timezone','Asia/Shanghai');
class Sms{
	private $_error = "";
	private $_status = array(
		'Missing username' => '用户名为空',
		'Missing password' => '密码为空',
		'Missing apikey' => 'APIKEY为空',
		'Missing recipient' => '手机号为空',
		'Missing message content' => '短信内容为空',
		'Account is blocked' => '短信账号被禁用',
		'Unrecognized encoding' => '编码未能识别',
		'APIKEY or password error' => 'APIKEY 或密码错误',
		'Unauthorized IP address' => '未授权 IP 地址',
		'Account balance is insufficient' => '余额不足',
		'Throughput Rate Exceeded' => '发送频率受限',
		'Invalid md5 password length' => 'MD5 密码长度非 32 位',
	);
	protected $_str = '1234567890';
	protected function error($error){
		$this->_error = $error;
	}
	public function getError(){
		return $this->_error;
	}

	public function send($mobile){
		$content = substr(str_shuffle($this->_str),0,6);
		$content = '验证码'.$content;
		if(empty($mobile)){
			$this->error("手机号和内容不能为空");
			return false;
		}
		$mobile = $this->checkMobile($mobile);
		if(empty($mobile)){
			$this->error("手机号错误");
			return false;
		}

		$result = $this->post($mobile, $content);
		$this->saveResult($mobile, $content, $result);
		if($result["status"] != 0){
			$err = isset($this->_status[$result["code"]]) ? $this->_status[$result["code"]] : "发送失败";
			$this->error($err);
			return false;
		}
		return true;
	}

	protected function post($mobile, $content){
		$url = 'http://m.5c.com.cn/api/send/index.php';

		$username = "zttgr";
		$password = "asdf1234";
		$apikey = "02d378c8bc7b474b319fdc85d0306b58";
		$encode = "utf-8";

		$pwd_md5 = md5($password);
		$mobile = is_array($mobile) ? implode(",", $mobile) : $mobile;
		$content = urlencode($content);

		$post = array(
		 	'username' => $username,
		 	'password_md5' => $pwd_md5,
		 	'apikey' => $apikey,
		 	'mobile' => $mobile,
		 	'content' => $content,
		 	'encode' => $encode,
		);

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_TIMEOUT, 15);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		$data = curl_exec($ch);
		curl_close($ch);

		return $this->parseResult($data);
	}

	protected function checkMobile($mobile) {
		$mobile = is_array($mobile) ? $mobile : preg_split("/\s*,\s*/", trim($mobile));
		foreach($mobile as $key => $val){
			if(preg_match('/^\+?\d{4,13}$/', $val) == 0){
				unset($mobile[$key]);
			}
		}
		return $mobile;
	}

	protected function parseResult($data){
		list($status, $code) = explode(":", $data);
		$status = strtolower($status) =='success' ? 0 : 1;
		return array(
			"status" => $status,
			"code" => $code,
		);
	}

	protected function saveResult($mobile, $content, $result){
		$path = __DIR__ . "/sms/";
		if(!is_dir($path)){
			mkdir($path, 0777, true);
		}

		$time = time();
		$file = $path . 'sms_' . date("Ym", $time) . ".csv";

		$date = date('Y-m-d H:i:s', $time);
		$mobile = is_array($mobile) ? implode(",", $mobile) : $mobile;
		$status = $result["status"] == 0 ? "success" : "error";
		$code = $result["code"];

		$content = "{$date}\t{$mobile}\t{$status}\t{$code}\t{$content}\n";
		return file_put_contents($file, $content, FILE_APPEND) ? true : false;
	}

	protected function getCode($mobile, $content, $result){
		$path = __DIR__ . "/sms/";
		if(!is_dir($path)){
			mkdir($path, 0777, true);
		}

		$time = time();
		$file = $path . 'sms_' . date("Ym", $time) . ".csv";

		$date = date('Y-m-d H:i:s', $time);
		$mobile = is_array($mobile) ? implode(",", $mobile) : $mobile;
		$status = $result["status"] == 0 ? "success" : "error";
		$code = $result["code"];

		$content = "{$date}\t{$mobile}\t{$status}\t{$code}\t{$content}\n";
		return file_put_contents($file, $content, FILE_APPEND) ? true : false;
	}



}

//判断发送频率是否可以发送短信
function setSendTimes($mobile){

	if( !isset( $_SESSION[$mobile]['amount'] ) ){
		$_SESSION[$mobile]['amount'] = 1;
		$_SESSION[$mobile]['time'] = time();

	}else{
		$_SESSION[$mobile]['amount'] = intval( $_SESSION[$mobile]['amount'] ) + 1;

	}

	$amount = intval( $_SESSION[$mobile]['amount'] );
	if( $amount > 3 ){
		$num = time()-$_SESSION[$mobile]['time'];
		if( $num >= 60 ){
			if(isset($_SESSION[$mobile])){
				unset($_SESSION[$mobile]);
			}
		}
		return false;
	}else{
		return true;
	}
}

//获取验证码
function getCode($mobile){
	
	$code = '';
	$path = __DIR__ . "/sms/";
	$time = time();
	$file_path = $path . 'sms_' . date("Ym", $time) . ".csv";

	if(file_exists($file_path)) {
		$file_arr = file($file_path);
		$amount = count($file_arr)-1;
		for ($i = $amount; $i >= 0; $i--) {//逐行读取文件内容
			$contentArr = explode("\t",$file_arr[$i]);
			$phoneNum = $contentArr[1];
			if($mobile == $phoneNum){
				$codeTime = strtotime($contentArr[0]);
				$tempTime = time() - $codeTime;
				if($tempTime < 180){
					return trim($contentArr[4]);
				}else{
					return $code;
				}
				break;
			}
		}
	}
	return $code;
}

$mobile = empty($_POST['mobile']) ? null : $_POST['mobile'];
$content = empty($_POST['content']) ? null : $_POST['content'];
$act = empty($_POST['act']) ? null : $_POST['act'];

$result = array(
	"status" => 0,
	"message" => "成功"
);

if( $act == 'send' ){

	//检测发送次数
	$bool = setSendTimes($mobile);
	if( !$bool ){
		$result = array(
			"status" => 1,
			"message" => "请稍后再试"
		);
		echo json_encode($result);
		exit;
	}

	$sms = new Sms();
	if($sms->send($mobile) != true){
		$result["status"] = 1;
		$result["message"] = $sms->getError();
	}
	echo json_encode($result);

}elseif( $act == 'checkcode' ){
	//验证验证码
	$code = getCode($mobile);
	if( !empty($code) && $content==$code){
		$result = array(
			"status" => 0,
			"message" => "验证通过"
		);
	}else{
		$result = array(
			"status" => 1,
			"message" => "验证失败"
		);
	}
	echo json_encode($result);
	exit;
}else{

}





